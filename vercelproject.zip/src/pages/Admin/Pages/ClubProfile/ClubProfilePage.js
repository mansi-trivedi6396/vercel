import React from 'react'
import ClubProfile from '../../Component/ClubProfile'
const ClubProfilePage=()=>
{
    return(
        <div>
            <ClubProfile/>
        </div>
    )
}
export default ClubProfilePage
import React from 'react'
import Shedule from '../../Component/Shedule'
const ShedulePage=()=>
{
    return(
        <div>
            <Shedule/>
        </div>
    )
}
export default ShedulePage
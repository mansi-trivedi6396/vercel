import React from 'react'
import UserProfile from '../../Component/Settings/UserProfile'

function UserProfilePage() {
    return (
        <UserProfile />
    )
}

export default UserProfilePage
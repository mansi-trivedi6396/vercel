import React from 'react'
import CourtSetting from '../../Component/Settings/CourtSetting'

function CourtSettingPage() {
    return (
        <CourtSetting />
    )
}

export default CourtSettingPage